goog.provide('pl.data.Model');

goog.require('goog.events.EventTarget');

/**
 * @constructor
 * @extends {goog.events.EventTarget}
 */
pl.data.Model = function() {

};
goog.inherits(pl.data.Model, goog.events.EventTarget);

goog.scope(function() {
  var c = pl.data.Model;

  goog.scope(function() {
    var p = c.prototype;

  });
});
