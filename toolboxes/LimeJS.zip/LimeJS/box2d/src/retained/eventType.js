goog.provide('pl.retained.EventType');

/**
 * Constants for event names.
 * @enum {string}
 */
pl.retained.EventType = {
  UPDATE: 'Update'
};
